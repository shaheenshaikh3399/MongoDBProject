package com.policyGeneration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PolicyGenerationApplicationTests {

	@Test
	void contextLoads() {
	}

}
