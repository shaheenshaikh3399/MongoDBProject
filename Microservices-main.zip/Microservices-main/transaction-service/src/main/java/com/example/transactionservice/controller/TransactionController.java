package com.example.transactionservice.controller;

import com.example.transactionservice.dto.TransactionDto;
import com.example.transactionservice.dto.TransactionResponseDto;
import com.example.transactionservice.entity.Transaction;
import com.example.transactionservice.service.TransactionService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/transaction")
@AllArgsConstructor
public class TransactionController {
    private final TransactionService transactionService;

    @PostMapping("/policy/{policyId}/customer/{id}")
    public ResponseEntity<TransactionResponseDto> transaction(@RequestBody @Valid Transaction transaction, @PathVariable("id") String customerId, @PathVariable("policyId") String policyId) {
        return new ResponseEntity<>(transactionService.saveTransaction(transaction, customerId, policyId), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<TransactionDto> getTransactionById(@PathVariable("id") String transactionId) {
        return ResponseEntity.ok(transactionService.getTransactionById(transactionId));
    }

    @GetMapping("/")
    public ResponseEntity<List<TransactionDto>> getAllTransactions() {
        return ResponseEntity.ok(transactionService.getAllTransaction());
    }

    @GetMapping("/byCustomerId/{id}")
    public ResponseEntity<List<TransactionDto>> getTransactionByCustomerId(@PathVariable("id") String customerId) {
        return ResponseEntity.ok(transactionService.getTransactionByCustomerId(customerId));
    }
}
