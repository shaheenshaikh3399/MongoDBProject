package com.example.transactionservice.service;

import com.example.transactionservice.dto.TransactionDto;
import com.example.transactionservice.dto.TransactionResponseDto;
import com.example.transactionservice.entity.Transaction;

import java.util.List;

public interface TransactionService {
    TransactionResponseDto saveTransaction(Transaction transaction, String customerId, String policyId);

    TransactionDto getTransactionById(String transactionId);

    List<TransactionDto> getAllTransaction();

    List<TransactionDto> getTransactionByCustomerId(String customerId);
}
