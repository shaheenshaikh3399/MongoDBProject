package com.example.transactionservice.entity;

public enum TransactionStatus {
    Successful, Unsuccessful
}
