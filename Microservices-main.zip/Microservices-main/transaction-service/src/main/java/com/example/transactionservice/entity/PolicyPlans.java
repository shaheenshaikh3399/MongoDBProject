package com.example.transactionservice.entity;

public enum PolicyPlans {
    Silver, Gold, Platinum
}
