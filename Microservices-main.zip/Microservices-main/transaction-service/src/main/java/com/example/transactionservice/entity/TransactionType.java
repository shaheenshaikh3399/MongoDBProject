package com.example.transactionservice.entity;

public enum TransactionType {
    Card, Upi
}
