package com.example.transactionservice.feign;

import com.example.transactionservice.dto.SelectionDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "SELECTION-SERVICE", path = "${selection.service.path}")
public interface SelectionFeignClient {
    @GetMapping("/byCustomer/{id}")
    ResponseEntity<SelectionDto> getSelectedPolicyByCustomerId(@PathVariable("id") String customerId);
}
