package com.example.transactionservice.service.impl;

import com.example.transactionservice.dto.PoliciesDto;
import com.example.transactionservice.dto.SelectionDto;
import com.example.transactionservice.dto.TransactionDto;
import com.example.transactionservice.dto.TransactionResponseDto;
import com.example.transactionservice.entity.Transaction;
import com.example.transactionservice.entity.TransactionStatus;
import com.example.transactionservice.exception.GlobalExceptionHandler;
import com.example.transactionservice.feign.PoliciesFeignClient;
import com.example.transactionservice.feign.SelectionFeignClient;
import com.example.transactionservice.repository.TransactionRepository;
import com.example.transactionservice.service.TransactionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class TransactionServiceImpl implements TransactionService {
    private final TransactionRepository transactionRepository;
    private final SelectionFeignClient selectionFeignClient;
    private final PoliciesFeignClient policiesFeignClient;

    @Override
    public TransactionResponseDto saveTransaction(Transaction transaction, String customerId, String policyId) {
        log.info("Inside saveTransaction");
        transaction.setCustomerId(customerId);
        transaction.setPolicyId(policyId);
        transaction.setTransactionId(UUID.randomUUID().toString());
        transactionRepository.save(transaction);
        SelectionDto selectionDto = selectionFeignClient.getSelectedPolicyByCustomerId(customerId).getBody();
        PoliciesDto policiesDto = policiesFeignClient.getPolicyById(policyId).getBody();
        assert selectionDto != null;
        assert policiesDto != null;
        if (transaction.getTransactionStatus().equals(TransactionStatus.Successful)) {
            return TransactionResponseDto.builder()
                    .message("Hi " + Objects.requireNonNull(selectionDto.getCustomerName()) + " total amount to be paid for" +
                            " the policy: " + policiesDto.getPoliciesId() + " is: " + policiesDto.getAmount())
                    .status("Transaction status: " + transaction.getTransactionStatus())
                    .build();
        } else if (transaction.getTransactionStatus().equals(TransactionStatus.Unsuccessful)) {
            return TransactionResponseDto.builder()
                    .message("Hi " + Objects.requireNonNull(selectionDto.getCustomerName()) + " total amount to be paid for" +
                            " the policy: " + policiesDto.getPoliciesId() + " is: " + policiesDto.getAmount())
                    .status("Transaction status: " + transaction.getTransactionStatus())
                    .build();
        } else {
            throw new GlobalExceptionHandler("Transaction is gateway is down, Please try again later!!!");
        }
    }

    @Override
    public TransactionDto getTransactionById(String transactionId) {
        log.info("Inside getTransactionById");
        Transaction transaction = transactionRepository.findById(transactionId).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Transaction details with id: %s not found!!", transactionId)
        ));
        return mapToDto(transaction);
    }

    @Override
    public List<TransactionDto> getAllTransaction() {
        log.info("Inside getAllTransaction");
        return transactionRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<TransactionDto> getTransactionByCustomerId(String customerId) {
        log.info("Inside getTransactionByCustomerId");
        List<Transaction> transactions = transactionRepository.findByCustomerId(customerId);
        return transactions.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private TransactionDto mapToDto(Transaction transaction) {
        return TransactionDto.builder()
                .transactionId(transaction.getTransactionId())
                .transactionType(transaction.getTransactionType())
                .transactionStatus(transaction.getTransactionStatus())
                .policyDetails(policiesFeignClient.getPolicyById(transaction.getPolicyId()).getBody())
                .selectedDetails(selectionFeignClient.getSelectedPolicyByCustomerId(transaction.getCustomerId()).getBody())
                .build();
    }
}
