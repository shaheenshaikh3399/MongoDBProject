package com.example.transactionservice.dto;

import com.example.transactionservice.entity.TransactionStatus;
import com.example.transactionservice.entity.TransactionType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionDto {
    private String transactionId;
    private TransactionType transactionType;
    private TransactionStatus transactionStatus;
    @JsonIgnore
    private PoliciesDto policyDetails;
    private SelectionDto selectedDetails;
}
