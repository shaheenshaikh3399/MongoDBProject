package com.example.transactionservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class Transaction {
    @Id
    private String transactionId;
    private TransactionType transactionType;
    private TransactionStatus transactionStatus;
    private String policyId;
    private String customerId;
}
