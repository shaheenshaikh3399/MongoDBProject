package com.example.catalogservice.entity;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class Catalog {
    @Id
    private String catalogId;
    @Length(min = 5, max = 50)
    @NotBlank
    private String catalogName;
    @Length(min = 5, max = 20000)
    @NotBlank
    private String catalogDescription;
}
