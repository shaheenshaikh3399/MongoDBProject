package com.example.catalogservice.service;

import com.example.catalogservice.dto.CatalogDto;
import com.example.catalogservice.entity.Catalog;

import java.util.List;
import java.util.Optional;

public interface CatalogService {
    CatalogDto addAndSaveCatalog(Catalog catalog);

    CatalogDto getCatalogById(String catalogId);

    List<CatalogDto> getAll();

    CatalogDto getCatalogByName(String catalogName);

}
