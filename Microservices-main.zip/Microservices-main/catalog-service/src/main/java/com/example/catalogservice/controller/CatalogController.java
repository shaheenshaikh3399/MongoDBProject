package com.example.catalogservice.controller;

import com.example.catalogservice.dto.CatalogDto;
import com.example.catalogservice.entity.Catalog;
import com.example.catalogservice.service.CatalogService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/catalogs")
@AllArgsConstructor
public class CatalogController {
    private final CatalogService catalogService;

    @PostMapping("/")
    public ResponseEntity<CatalogDto> addCatalog(@RequestBody @Valid Catalog catalog) {
        return new ResponseEntity<>(catalogService.addAndSaveCatalog(catalog), HttpStatus.CREATED);
    }

    @GetMapping("/byId/{id}")
    public ResponseEntity<CatalogDto> getCatalogById(@PathVariable ("id") String catalogId) {
        return ResponseEntity.ok(catalogService.getCatalogById(catalogId));
    }

    @GetMapping("/")
    public ResponseEntity<List<CatalogDto>> getAll() {
        return ResponseEntity.ok(catalogService.getAll());
    }

    @GetMapping("/byName/{name}")
    public ResponseEntity<CatalogDto> getCatalogByName(@PathVariable ("name") String catalogName) {
        return ResponseEntity.ok(catalogService.getCatalogByName(catalogName));
    }

}
