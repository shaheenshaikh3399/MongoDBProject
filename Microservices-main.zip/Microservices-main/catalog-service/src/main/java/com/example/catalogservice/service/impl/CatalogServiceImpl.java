package com.example.catalogservice.service.impl;

import com.example.catalogservice.dto.CatalogDto;
import com.example.catalogservice.entity.Catalog;
import com.example.catalogservice.exception.GlobalExceptionHandler;
import com.example.catalogservice.repository.CatalogRepository;
import com.example.catalogservice.service.CatalogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class CatalogServiceImpl implements CatalogService {
    private final CatalogRepository catalogRepository;

    @Override
    public CatalogDto addAndSaveCatalog(Catalog catalog) {
        log.info("Inside addAndSaveCatalog");
        catalog.setCatalogId(UUID.randomUUID().toString());
        if (catalogRepository.findByCatalogName(catalog.getCatalogName()).isPresent()) {
            throw new GlobalExceptionHandler(String.format("Catalog already exists with the name: %s", catalog.getCatalogName()));
        }
        return mapToCatalogDto(catalogRepository.save(catalog));
    }

    @Override
    public CatalogDto getCatalogById(String catalogId) {
        log.info("Inside getCatalogById");
        Catalog catalog = catalogRepository.findById(catalogId).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Catalog not found with the id: %s", catalogId)));
        return mapToCatalogDto(catalog);
    }

    @Override
    public List<CatalogDto> getAll() {
        log.info("Inside getAll");
        return catalogRepository.findAll()
                .stream()
                .map(this::mapToCatalogDto)
                .collect(Collectors.toList());
    }

    @Override
    public CatalogDto getCatalogByName(String catalogName) {
        log.info("Inside getCatalogByName");
        Catalog catalog = catalogRepository.findByCatalogName(catalogName).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Catalog not found with the name: %s", catalogName)));
        return mapToCatalogDto(catalog);
    }

    public CatalogDto mapToCatalogDto(Catalog catalog) {
        return CatalogDto.builder()
                .catalogId(catalog.getCatalogId())
                .catalogName(catalog.getCatalogName())
                .catalogDesc(catalog.getCatalogDescription())
                .build();
    }

}
