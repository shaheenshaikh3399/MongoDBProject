package com.example.generationservice.repository;

import com.example.generationservice.entity.Generation;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface GenerationRepository extends MongoRepository<Generation, String> {
    List<Generation> findByCustomerId(String customerId);
}
