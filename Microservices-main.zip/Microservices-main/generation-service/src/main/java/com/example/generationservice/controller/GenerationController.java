package com.example.generationservice.controller;

import com.example.generationservice.dto.GenerationDto;
import com.example.generationservice.dto.GenerationResponseDto;
import com.example.generationservice.service.GenerationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/document")
@AllArgsConstructor
public class GenerationController {
    private final GenerationService generationService;

    @PostMapping("/customer/{id}/policy/{policyId}/transaction/{tId}/generate")
    public ResponseEntity<GenerationResponseDto> generateDocument( @PathVariable("id") String customerId,
                                                                  @PathVariable("policyId") String policyId,
                                                                  @PathVariable ("tId") String transactionId) {
        return new ResponseEntity<>(generationService.generateDocument(customerId, policyId, transactionId), HttpStatus.CREATED);
    }
    @GetMapping("/details/byId/{id}")
    public ResponseEntity<GenerationDto> getDocumentById(@PathVariable ("id") String documentId) {
        return ResponseEntity.ok(generationService.getDocumentById(documentId));
    }
    @GetMapping("/byCustomerId/{id}")
    public ResponseEntity<List<GenerationDto>> getDocuments(@PathVariable ("id") String customerId) {
        return ResponseEntity.ok(generationService.getDocuments(customerId));
    }
}
