package com.example.generationservice.service.impl;


import com.example.generationservice.dto.GenerationDto;
import com.example.generationservice.dto.GenerationResponseDto;
import com.example.generationservice.dto.SelectionDto;
import com.example.generationservice.dto.TransactionDto;
import com.example.generationservice.entity.EmailRequest;
import com.example.generationservice.entity.Generation;
import com.example.generationservice.entity.TransactionStatus;
import com.example.generationservice.exception.GlobalExceptionHandler;
import com.example.generationservice.feign.NotificationFeignClient;
import com.example.generationservice.feign.SelectionFeignClient;
import com.example.generationservice.feign.TransactionFeignClient;
import com.example.generationservice.repository.GenerationRepository;
import com.example.generationservice.service.GenerationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class GenerationServiceImpl implements GenerationService {
    private final GenerationRepository generationRepository;
    private final TransactionFeignClient transactionFeignClient;
    private final NotificationFeignClient notificationFeignClient;
    private final SelectionFeignClient selectionFeignClient;

    private static final String adminEmail = "insuranceadmin@gmail.com";

    @Override
    public GenerationResponseDto generateDocument(String customerId, String policyId, String transactionId) {
        log.info("Inside generateDocument");
        Generation generation = Generation.builder()
                .documentId(UUID.randomUUID().toString())
                .customerId(customerId)
                .policyId(policyId)
                .transactionId(transactionId)
                .build();
        TransactionDto transactionDto = transactionFeignClient.getTransactionById(transactionId).getBody();
        SelectionDto selectionDto = selectionFeignClient.getSelectedPolicyByCustomerId(customerId).getBody();
        generationRepository.save(generation);
        assert transactionDto != null;
        if (transactionDto.getTransactionStatus().equals(TransactionStatus.Successful)) {
            assert selectionDto != null;
            GenerationResponseDto generationResponseDto = GenerationResponseDto.builder()
                    .documentId(generation.getDocumentId())
                    .message("Dear customer: " + Objects.requireNonNull(selectionDto.getCustomerName()) + " the documentId is generated, please " +
                            "find all the details on your email.")
                    .build();
            EmailRequest emailRequest = EmailRequest.builder()
                    .documentId(generation.getDocumentId())
                    .emailTo(Objects.requireNonNull(selectionDto.getCustomerEmail()))
                    .emailFrom(adminEmail)
                    .emailSubject("Policy Document for policy: " + selectionDto.getPolicyDetails().getPolicyName())
                    .emailBody("Dear " + selectionDto.getCustomerName() + ",PFB the document" +
                            GenerationDto.builder()
                                    .documentId(generation.getDocumentId())
                                    .selectedDetails(selectionDto)
                                    .transactionDetails(transactionDto)
                                    .build())
                    .build();
            notificationFeignClient.sendEmail(emailRequest, generation.getDocumentId());
            return generationResponseDto;
        } else if (transactionDto.getTransactionStatus().equals(TransactionStatus.Unsuccessful)) {
            throw new GlobalExceptionHandler("Sorry the document cannot be generated as transaction is: " + transactionDto.getTransactionStatus());
        } else {
            throw new GlobalExceptionHandler("Sorry, cannot generate the document...!!!");
        }
    }

    @Override
    public GenerationDto getDocumentById(String documentId) {
        log.info("Inside getDocumentById");
        Generation generation = generationRepository.findById(documentId).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Document not found with the id: %s", documentId)
        ));
        return mapToDto(generation);
    }

    @Override
    public List<GenerationDto> getDocuments(String customerId) {
        log.info("Inside getDocuments");
        List<Generation> documents = generationRepository.findByCustomerId(customerId);
        if (documents.isEmpty()) {
            throw new GlobalExceptionHandler("You have no emails!!!");
        }
        return documents.stream().map(this::mapToDto).collect(Collectors.toList());
    }

    private GenerationDto mapToDto(Generation generation) {
        return GenerationDto.builder()
                .documentId(generation.getDocumentId())
                .selectedDetails(Objects.requireNonNull(selectionFeignClient.getSelectedPolicyByCustomerId(generation.getCustomerId()).getBody()))
                .transactionDetails(Objects.requireNonNull(transactionFeignClient.getTransactionById(generation.getTransactionId()).getBody()))
                .build();
    }
}
