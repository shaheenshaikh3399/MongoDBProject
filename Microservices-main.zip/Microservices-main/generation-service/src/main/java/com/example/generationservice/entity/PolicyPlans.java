package com.example.generationservice.entity;

public enum PolicyPlans {
    Silver, Gold, Platinum
}
