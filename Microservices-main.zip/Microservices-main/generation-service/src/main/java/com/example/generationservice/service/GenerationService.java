package com.example.generationservice.service;

import com.example.generationservice.dto.GenerationDto;
import com.example.generationservice.dto.GenerationResponseDto;
import com.example.generationservice.entity.Generation;

import java.util.List;

public interface GenerationService {
    GenerationResponseDto generateDocument(String customerId, String policyId, String transactionId);

    GenerationDto getDocumentById(String documentId);

    List<GenerationDto> getDocuments(String customerId);
}
