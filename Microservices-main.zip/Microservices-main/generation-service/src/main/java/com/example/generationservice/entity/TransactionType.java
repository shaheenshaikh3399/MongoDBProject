package com.example.generationservice.entity;

public enum TransactionType {
    Card, Upi
}
