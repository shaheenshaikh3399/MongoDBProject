package com.example.generationservice.feign;

import com.example.generationservice.dto.TransactionDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "TRANSACTION-SERVICE", path = "${transaction.service.path}")
public interface TransactionFeignClient {
    @GetMapping("/{id}")
    ResponseEntity<TransactionDto> getTransactionById(@PathVariable("id") String transactionId);
}
