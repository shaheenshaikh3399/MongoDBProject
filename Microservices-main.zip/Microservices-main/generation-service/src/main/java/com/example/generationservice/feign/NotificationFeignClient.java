package com.example.generationservice.feign;

import com.example.generationservice.dto.EmailRequestDto;
import com.example.generationservice.entity.EmailRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "NOTIFICATION-SERVICE", path = "${notification.service.path}")
public interface NotificationFeignClient {
    @PostMapping("/send/document/{id}")
    ResponseEntity<EmailRequestDto> sendEmail(@RequestBody EmailRequest emailRequest, @PathVariable("id") String documentId);
}
