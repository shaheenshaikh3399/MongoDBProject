package com.example.generationservice.entity;

public enum TransactionStatus {
    Successful, Unsuccessful
}
