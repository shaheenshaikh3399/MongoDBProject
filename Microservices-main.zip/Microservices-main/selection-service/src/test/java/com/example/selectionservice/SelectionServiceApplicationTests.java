package com.example.selectionservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SelectionServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
