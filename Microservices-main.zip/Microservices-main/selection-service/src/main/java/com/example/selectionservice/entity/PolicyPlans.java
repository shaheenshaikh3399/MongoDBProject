package com.example.selectionservice.entity;

public enum PolicyPlans {
    Silver, Gold, Platinum
}
