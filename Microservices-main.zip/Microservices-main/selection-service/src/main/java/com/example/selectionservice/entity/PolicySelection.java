package com.example.selectionservice.entity;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class PolicySelection {
    @Id
    private String customerId;
    private String policyId;
    private String catalogId;
    @NotBlank
    @NotNull
    @Length(min = 3, max = 30)
    private String customerName;
    @Email
    @NotBlank
    @Length(min = 5, max = 40)
    private String customerEmail;
    @NotBlank
    @Length(max = 10)
    private String contactNumber;
    @NotBlank
    @Length(max = 2)
    private String age;
}
