package com.example.selectionservice.exception;

import com.example.selectionservice.dto.CustomApiResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CustomApiExceptionHandler {
    @ExceptionHandler(GlobalExceptionHandler.class)
    public ResponseEntity<CustomApiResponseDto> customApiResponseExceptionHandler(GlobalExceptionHandler exceptionHandler) {
        return new ResponseEntity<CustomApiResponseDto>(CustomApiResponseDto.builder()
                .message(exceptionHandler.getMessage())
                .success(true)
                .build(), HttpStatus.CREATED);
    }
}
