package com.example.selectionservice.service;

import com.example.selectionservice.dto.SelectionDto;
import com.example.selectionservice.dto.SelectionResponseDto;
import com.example.selectionservice.entity.PolicySelection;

import java.util.List;

public interface SelectionService {
    SelectionResponseDto addAndSaveDetails(PolicySelection policySelection, String policyId, String catalogId);

    SelectionDto getSelectedPolicyByCustomerId(String customerId);

    List<SelectionDto> getAllSelectedPolicesByCustomer();
}
