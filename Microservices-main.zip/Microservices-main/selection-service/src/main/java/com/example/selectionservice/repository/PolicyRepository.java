package com.example.selectionservice.repository;

import com.example.selectionservice.dto.SelectionDto;
import com.example.selectionservice.entity.PolicySelection;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PolicyRepository extends MongoRepository<PolicySelection, String> {
    Optional<SelectionDto> findByCustomerEmail(String customerEmail);
}
