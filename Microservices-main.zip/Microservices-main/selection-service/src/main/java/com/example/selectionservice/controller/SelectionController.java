package com.example.selectionservice.controller;

import com.example.selectionservice.dto.SelectionDto;
import com.example.selectionservice.dto.SelectionResponseDto;
import com.example.selectionservice.entity.PolicySelection;
import com.example.selectionservice.service.SelectionService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/selected")
@AllArgsConstructor
public class SelectionController {
    private final SelectionService selectionService;

    @PostMapping("/catalog/{catId}/policy/{policyId}")
    public ResponseEntity<SelectionResponseDto> addPolicyDetails(@RequestBody @Valid PolicySelection policySelection, @PathVariable("policyId") String policyId, @PathVariable ("catId") String catalogId) {
        return new ResponseEntity<>(selectionService.addAndSaveDetails(policySelection, policyId, catalogId), HttpStatus.CREATED);
    }

    @GetMapping("/byCustomer/{id}")
    public ResponseEntity<SelectionDto> getSelectedPolicyByCustomerId(@PathVariable("id") String customerId) {
        return ResponseEntity.ok(selectionService.getSelectedPolicyByCustomerId(customerId));
    }

    @GetMapping("/")
    public ResponseEntity<List<SelectionDto>> getAllSelectedPolicesByCustomer() {
        return ResponseEntity.ok(selectionService.getAllSelectedPolicesByCustomer());
    }
}
