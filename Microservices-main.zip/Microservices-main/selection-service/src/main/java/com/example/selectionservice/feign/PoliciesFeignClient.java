package com.example.selectionservice.feign;

import com.example.selectionservice.dto.PoliciesDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "POLICIES-SERVICE", path = "${policies.service.path}")
public interface PoliciesFeignClient {
    @GetMapping("/{id}")
    ResponseEntity<PoliciesDto> getPolicyById(@PathVariable("id") String policyId);
}
