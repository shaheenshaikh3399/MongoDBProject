package com.example.selectionservice.service.impl;

import com.example.selectionservice.dto.SelectionDto;
import com.example.selectionservice.dto.SelectionResponseDto;
import com.example.selectionservice.entity.PolicySelection;
import com.example.selectionservice.exception.GlobalExceptionHandler;
import com.example.selectionservice.feign.CatalogFeignClient;
import com.example.selectionservice.feign.PoliciesFeignClient;
import com.example.selectionservice.repository.PolicyRepository;
import com.example.selectionservice.service.SelectionService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class SelectionServiceImpl implements SelectionService {
    private final PolicyRepository policyRepository;
    private final CatalogFeignClient catalogFeignClient;
    private final PoliciesFeignClient policiesFeignClient;
    @Override
    public SelectionResponseDto addAndSaveDetails(PolicySelection policySelection, String policyId, String catalogId) {
        log.info("Inside addAndSaveDetails");
        policySelection.setPolicyId(policyId);
        policySelection.setCatalogId(catalogId);
        policySelection.setCustomerId(UUID.randomUUID().toString());
        if(policyRepository.findByCustomerEmail(policySelection.getCustomerEmail()).isPresent()) {
            throw new GlobalExceptionHandler(String.format("Customer exists with the email: %s", policySelection.getCustomerEmail()));
        }
        mapToDto(policyRepository.save(policySelection));
        return SelectionResponseDto.builder()
                .message("Hi "+policySelection.getCustomerName()+" you have selected the policy: "+ Objects.requireNonNull(policiesFeignClient.getPolicyById(policyId).getBody()).getPolicyName())
                .amountToBePaid("Amount to be paid: "+ Objects.requireNonNull(policiesFeignClient.getPolicyById(policyId).getBody()).getAmount())
                .build();
    }

    @Override
    public SelectionDto getSelectedPolicyByCustomerId(String customerId) {
        log.info("Inside getSelectedPolicyByCustomerId");
        PolicySelection policySelection = policyRepository.findById(customerId).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Customer not found with id: %s", customerId)
        ));
        return mapToDto(policySelection);
    }

    @Override
    public List<SelectionDto> getAllSelectedPolicesByCustomer() {
        log.info("Inside getAllSelectedPolicesByCustomer");
        return policyRepository.findAll()
                .stream()
                .map(this::mapToDto)
                .collect(Collectors.toList());
    }

    private SelectionDto mapToDto(PolicySelection policySelection) {
        return SelectionDto.builder()
                .customerId(policySelection.getCustomerId())
                .customerName(policySelection.getCustomerName())
                .customerEmail(policySelection.getCustomerEmail())
                .contactNumber(policySelection.getContactNumber())
                .age(policySelection.getAge())
                .policyDetails(policiesFeignClient.getPolicyById(policySelection.getPolicyId()).getBody())
                .catalogDetails(catalogFeignClient.getCatalogById(policySelection.getCatalogId()).getBody())
                .build();
    }
}
