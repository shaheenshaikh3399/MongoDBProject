package com.example.policies.entity;

public enum PolicyPlans {
    Silver, Gold, Platinum
}
