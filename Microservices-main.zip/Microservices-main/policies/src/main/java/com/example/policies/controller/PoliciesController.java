package com.example.policies.controller;

import com.example.policies.dto.PoliciesDto;
import com.example.policies.entity.Policies;
import com.example.policies.service.PoliciesService;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v1/policies")
public class PoliciesController {
    private final PoliciesService policiesService;

    @PostMapping("/addTo/catalog/{id}")
    public ResponseEntity<PoliciesDto> addPolicies(@RequestBody @Valid Policies policies, @PathVariable("id") String catalogId) {
        return new ResponseEntity<>(policiesService.addAndSavePolicies(policies, catalogId), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PoliciesDto> getPolicyById(@PathVariable ("id") String policyId) {
        return ResponseEntity.ok(policiesService.getPolicyById(policyId));
    }

    @GetMapping("/byName/{name}")
    public ResponseEntity<PoliciesDto> getPolicyByName(@PathVariable ("name") String policyName) {
        return ResponseEntity.ok(policiesService.getPolicyByName(policyName));
    }

    @GetMapping("/byCatalog/{id}")
    public ResponseEntity<List<PoliciesDto>> getPoliciesByCatalog(@PathVariable ("id") String catalogId) {
        return ResponseEntity.ok(policiesService.getAllPolicies(catalogId));
    }
}
