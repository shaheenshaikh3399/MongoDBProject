package com.example.policies.entity;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class Policies {
    @Id
    private String policiesId;
    @Length(min = 5, max = 40)
    @NotBlank
    private String policyName;
    private PolicyPlans policyPlans;
    @Length(min = 5, max = 100000)
    @NotBlank
    private String description;
    private String amount;
    private String catalogId;
}
