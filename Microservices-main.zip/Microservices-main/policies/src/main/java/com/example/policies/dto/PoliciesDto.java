package com.example.policies.dto;

import com.example.policies.entity.PolicyPlans;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PoliciesDto {
    private String policiesId;
    private String policyName;
    private String amount;
    private PolicyPlans policyPlans;
    private String description;
    @JsonIgnore
    private CatalogDto catalogDetails;
}
