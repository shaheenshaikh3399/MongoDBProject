package com.example.policies.repositroy;

import com.example.policies.entity.Policies;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface PoliciesRepository extends MongoRepository<Policies, String> {
    Optional<Policies> findByPolicyName(String policyName);

    List<Policies> findByCatalogId(String catalogId);
}
