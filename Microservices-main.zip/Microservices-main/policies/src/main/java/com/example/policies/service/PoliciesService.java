package com.example.policies.service;

import com.example.policies.dto.PoliciesDto;
import com.example.policies.entity.Policies;

import java.util.List;

public interface PoliciesService {
    PoliciesDto addAndSavePolicies(Policies policies, String catalogId);

    PoliciesDto getPolicyById(String policyId);


    PoliciesDto getPolicyByName(String policyName);

    List<PoliciesDto> getAllPolicies(String catalogId);
}
