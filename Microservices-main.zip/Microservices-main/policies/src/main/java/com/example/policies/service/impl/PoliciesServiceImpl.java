package com.example.policies.service.impl;

import com.example.policies.dto.CatalogDto;
import com.example.policies.dto.PoliciesDto;
import com.example.policies.entity.Policies;
import com.example.policies.exception.GlobalExceptionHandler;
import com.example.policies.feign.CatalogFeignClient;
import com.example.policies.repositroy.PoliciesRepository;
import com.example.policies.service.PoliciesService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class PoliciesServiceImpl implements PoliciesService {
    private final PoliciesRepository policiesRepository;
    private final CatalogFeignClient catalogFeignClient;

    @Override
    public PoliciesDto addAndSavePolicies(Policies policies, String catalogId) {
        log.info("Inside addAndSavePolicies");
        policies.setPoliciesId(UUID.randomUUID().toString());
        policies.setCatalogId(catalogId);
        if (policiesRepository.findByPolicyName(policies.getPolicyName()).isPresent()) {
            throw new GlobalExceptionHandler(String.format("Catalog already exists with the name: %s", policies.getPolicyName()));
        }
        return mapToPoliciesDto(policiesRepository.save(policies));
    }

    @Override
    public PoliciesDto getPolicyById(String policyId) {
        log.info("Inside getCatalogById");
        Policies policies = policiesRepository.findById(policyId).orElseThrow(() -> new GlobalExceptionHandler
                (String.format("Catalog not found with the id: %s", policyId)));
        return mapToPoliciesDto(policies);
    }


    @Override
    public PoliciesDto getPolicyByName(String policyName) {
        log.info("Inside getPolicyByName");
        Policies policies = policiesRepository.findByPolicyName(policyName).orElseThrow(() -> new GlobalExceptionHandler
                (String.format("Catalog not found with the id: %s", policyName)));
        return mapToPoliciesDto(policies);
    }

    @Override
    public List<PoliciesDto> getAllPolicies(String catalogId) {
        log.info("Inside getAllPolicies");
        CatalogDto catalogDto = catalogFeignClient.getCatalogById(catalogId).getBody();
        assert catalogDto != null;
        List<Policies> policiesList = policiesRepository.findByCatalogId(catalogDto.getCatalogId());
        return policiesList.stream().map(this::mapToPoliciesDto).collect(Collectors.toList());
    }


    public PoliciesDto mapToPoliciesDto(Policies policies) {
        return PoliciesDto.builder()
                .policiesId(policies.getPoliciesId())
                .policyName(policies.getPolicyName())
                .amount(policies.getAmount())
                .policyPlans(policies.getPolicyPlans())
                .description(policies.getDescription())
                .catalogDetails(catalogFeignClient.getCatalogById(policies.getCatalogId()).getBody())
                .build();
    }
}
