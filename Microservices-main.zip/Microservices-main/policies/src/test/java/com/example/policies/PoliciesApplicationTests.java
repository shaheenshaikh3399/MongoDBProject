package com.example.policies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PoliciesApplicationTests {

	@Test
	void contextLoads() {
	}

}
