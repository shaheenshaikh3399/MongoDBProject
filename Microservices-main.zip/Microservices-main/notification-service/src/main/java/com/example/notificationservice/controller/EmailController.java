package com.example.notificationservice.controller;

import com.example.notificationservice.dto.EmailRequestDto;
import com.example.notificationservice.entity.EmailRequest;
import com.example.notificationservice.service.EmailService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/notification")
@AllArgsConstructor
public class EmailController {
    private final EmailService emailService;

    @PostMapping("/send/document/{id}")
    public ResponseEntity<EmailRequestDto> sendEmail(@RequestBody EmailRequest emailRequest, @PathVariable("id") String documentId) {
        return new ResponseEntity<>(emailService.sendEmail(emailRequest, documentId), HttpStatus.CREATED);
    }

    @GetMapping("/getById/{id}")
    public ResponseEntity<EmailRequestDto> getEmailByNotificationId(@PathVariable ("id") String notificationId) {
        return ResponseEntity.ok(emailService.getNotificationById(notificationId));
    }
    @GetMapping("/getByCustomerEmail/{id}")
    public ResponseEntity<List<EmailRequestDto>> getEmailForACustomer(@PathVariable ("id") String emailTo) {
        return ResponseEntity.ok(emailService.getNotificationsForACustomer(emailTo));
    }
}
