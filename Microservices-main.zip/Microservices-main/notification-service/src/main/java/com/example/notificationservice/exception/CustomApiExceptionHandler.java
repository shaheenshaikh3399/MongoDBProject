package com.example.notificationservice.exception;

import com.example.notificationservice.CustomApiResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CustomApiExceptionHandler {
    @ExceptionHandler(GlobalExceptionHandler.class)
    public ResponseEntity<CustomApiResponseDto> customApiResponseExceptionHandler(GlobalExceptionHandler exceptionHandler) {
        return new ResponseEntity<>(CustomApiResponseDto.builder()
                .message(exceptionHandler.getMessage())
                .success(true)
                .build(), HttpStatus.CREATED);
    }
}
