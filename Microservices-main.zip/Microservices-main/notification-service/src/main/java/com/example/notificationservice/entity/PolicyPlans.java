package com.example.notificationservice.entity;

public enum PolicyPlans {
    Silver, Gold, Platinum
}
