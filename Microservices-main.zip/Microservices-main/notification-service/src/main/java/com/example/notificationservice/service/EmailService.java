package com.example.notificationservice.service;

import com.example.notificationservice.dto.EmailRequestDto;
import com.example.notificationservice.entity.EmailRequest;

import java.util.List;

public interface EmailService {
    EmailRequestDto sendEmail(EmailRequest emailRequest, String documentId);

    EmailRequestDto getNotificationById(String notificationId);

    List<EmailRequestDto> getNotificationsForACustomer(String emailTo);
}
