package com.example.notificationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GenerationDto {
    private String documentId;
    private SelectionDto selectedDetails;
    private TransactionDto transactionDetails;
}
