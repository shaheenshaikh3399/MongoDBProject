package com.example.notificationservice.entity;

public enum TransactionType {
    Card, Upi
}
