package com.example.notificationservice.repository;

import com.example.notificationservice.entity.EmailRequest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface EmailRepository extends MongoRepository<EmailRequest, String> {
    List<EmailRequest> findByEmailTo(String emailTo);
}
