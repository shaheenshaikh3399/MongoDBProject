package com.example.notificationservice.feign;

import com.example.notificationservice.dto.GenerationDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "GENERATION-SERVICE", path = "${generation.service.path}")
public interface GenerationFeignClient {
    @GetMapping("/details/byId/{id}")
    ResponseEntity<GenerationDto> getDocumentById(@PathVariable("id") String documentId);
}
