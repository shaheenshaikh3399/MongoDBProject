package com.example.notificationservice.dto;


import com.example.notificationservice.entity.TransactionStatus;
import com.example.notificationservice.entity.TransactionType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TransactionDto {
    @JsonIgnore
    private SelectionDto selectedDetails;
    private String transactionId;
    private TransactionType transactionType;
    private TransactionStatus transactionStatus;
    @JsonIgnore
    private PoliciesDto policyDetails;
}
