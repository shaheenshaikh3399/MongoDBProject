package com.example.notificationservice.dto;

import com.example.notificationservice.entity.PolicyPlans;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PoliciesDto {
    private String policiesId;
    private String policyName;
    private String amount;
    private PolicyPlans policyPlans;
    private String description;
}
