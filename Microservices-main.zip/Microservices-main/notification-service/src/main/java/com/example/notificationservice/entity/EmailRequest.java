package com.example.notificationservice.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document
public class EmailRequest {
    @Id
    private String notificationId;
    private String documentId;
    private String emailFrom;
    private String emailTo;
    private String emailSubject;
    private String emailBody;
}
