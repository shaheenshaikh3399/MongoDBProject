package com.example.notificationservice.service.impl;

import com.example.notificationservice.dto.EmailRequestDto;
import com.example.notificationservice.dto.GenerationDto;
import com.example.notificationservice.entity.EmailRequest;
import com.example.notificationservice.exception.GlobalExceptionHandler;
import com.example.notificationservice.feign.GenerationFeignClient;
import com.example.notificationservice.repository.EmailRepository;
import com.example.notificationservice.service.EmailService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@Slf4j
@AllArgsConstructor
public class EmailServiceImpl implements EmailService {

    private final EmailRepository emailRepository;
    private final GenerationFeignClient generationFeignClient;
    @Override
    public EmailRequestDto sendEmail(EmailRequest emailRequest, String documentId) {
        log.info("Inside sendEmail");
        emailRequest.setNotificationId(UUID.randomUUID().toString());
        emailRequest.setDocumentId(documentId);
        return mapToDto(emailRepository.save(emailRequest));
    }

    @Override
    public EmailRequestDto getNotificationById(String notificationId) {
        log.info("Inside getNotificationById");
        EmailRequest emailRequest = emailRepository.findById(notificationId).orElseThrow(() -> new GlobalExceptionHandler(
                String.format("Notification with the id: %s not found", notificationId)
        ));
        return mapToDto(emailRequest);
    }

    @Override
    public List<EmailRequestDto> getNotificationsForACustomer(String emailTo) {
        log.info("Inside getNotificationForACustomer");
        List<EmailRequest> emails = emailRepository.findByEmailTo(emailTo);
        if(emails.isEmpty()) {
            throw new GlobalExceptionHandler(String.format("Dear %s, you have no emails", emailTo));
        }
        return emails.stream().map(this::mapToDto).collect(Collectors.toList());
    }
    private EmailRequestDto mapToDto(EmailRequest emailRequest) {
        return EmailRequestDto.builder()
                .notificationId(emailRequest.getNotificationId())
                .from(emailRequest.getEmailFrom())
                .to(emailRequest.getEmailTo())
                .subject(emailRequest.getEmailSubject())
                .body(GenerationDto.builder()
                        .documentId(emailRequest.getDocumentId())
                        .selectedDetails(Objects.requireNonNull(generationFeignClient.getDocumentById(emailRequest.getDocumentId()).getBody()).getSelectedDetails())
                        .transactionDetails(Objects.requireNonNull(generationFeignClient.getDocumentById(emailRequest.getDocumentId())
                                        .getBody()).getTransactionDetails())
                        .build())
                .build();
    }
}
