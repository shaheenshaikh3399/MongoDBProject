package com.example.notificationservice.entity;

public enum TransactionStatus {
    Successful, Unsuccessful
}
