# Microservices
This is a microservices demo project using spring boot and java.
The use case used for this project is Insurance Policy Purchase, that helps customer to purchase the insurance policies online.
It helps customer to select a insurance from a catalog, provide valid details for the selected policy, perform the transaction for the policy, generate the policy document and notify the customer of their purchase.

Tech Stack: 
Java, Maven, Spring Boot, MongoDb as database, Postman as REST client tool.

IDE:
IntelliJ IDEA

JDK Version: 
Amazon Corretto JDK 17
